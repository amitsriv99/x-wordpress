<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Bootstrap Blog
 */
?>

<div id="secondary" class="widget-area" role="complementary">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</div><!-- #secondary -->