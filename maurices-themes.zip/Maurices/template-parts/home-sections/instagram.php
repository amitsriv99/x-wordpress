<?php if ( is_active_sidebar( 'instagram' ) ) : ?>
	<div class="widget-instagram clearfix">
		<?php dynamic_sidebar( 'instagram' ); ?>
	</div>
<?php endif; ?>




